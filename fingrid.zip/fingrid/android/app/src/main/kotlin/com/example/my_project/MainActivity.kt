package com.mycompany.fingrid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
